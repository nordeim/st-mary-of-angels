export type SiteId = "rother" | "joseph";
export type Winner = SiteId | "tie";
export type Confidence = "Verified" | "Reasoned" | "Assumed";
export type FindingKind = "strength" | "gap" | "shared";

export interface SiteProfile {
  id: SiteId;
  name: string;
  short: string;
  version: string;
  url: string;
  repo: string;
  location: string;
  founded: string;
  tagline: string;
  audience: string;
  hero: string;
  heroFallback: string;
  heroAlt: string;
  accent: string;
}

export interface Token {
  name: string;
  hex: string;
  use: string;
}

export interface Dimension {
  id: string;
  label: string;
  weight: number;
  rother: number;
  joseph: number;
  winner: Winner;
  thesis: string;
  evidence: string;
  confidence: Confidence;
}

export interface Finding {
  id: string;
  kind: FindingKind;
  site: SiteId | "both";
  category: string;
  title: string;
  body: string;
  evidence: string;
  confidence: Confidence;
}

export interface MotionRow {
  name: string;
  rother: boolean;
  joseph: boolean;
  note: string;
}

export interface NavMap {
  label: string;
  children?: string[];
}

export const ROTHER_IMG =
  "https://images.pexels.com/photos/16538707/pexels-photo-16538707.jpeg?auto=compress&cs=tinysrgb&w=1800";
export const WHEAT_IMG =
  "https://images.pexels.com/photos/12873375/pexels-photo-12873375.jpeg?auto=compress&cs=tinysrgb&w=1400";
export const NAVE_IMG =
  "https://images.pexels.com/photos/18194715/pexels-photo-18194715.jpeg?auto=compress&cs=tinysrgb&w=1400";
export const ALTAR_IMG =
  "https://images.pexels.com/photos/11618377/pexels-photo-11618377.jpeg?auto=compress&cs=tinysrgb&w=1400";

export const sites: Record<SiteId, SiteProfile> = {
  rother: {
    id: "rother",
    name: "Blessed Stanley Rother Shrine",
    short: "Rother",
    version: "1.4.0",
    url: "https://rothershrine.jesspete.shop/",
    repo: "https://github.com/nordeim/rothershrine-v2",
    location: "Oklahoma City, USA",
    founded: "National shrine · martyr 1981 · beatified 2017",
    tagline: "The shepherd who stayed.",
    audience: "Pilgrims, parish groups, school tours",
    hero: "https://rothershrine.jesspete.shop/images/hero-shrine.jpg",
    heroFallback: ROTHER_IMG,
    heroAlt: "Sunlit Blessed Stanley Rother Shrine, Oklahoma City",
    accent: "#7c2a25",
  },
  joseph: {
    id: "joseph",
    name: "St Joseph's Church (Bukit Timah)",
    short: "St Joseph",
    version: "1.1.0",
    url: "https://st-joseph.jesspete.shop/",
    repo: "https://github.com/nordeim/st-joseph-bt",
    location: "Singapore",
    founded: "Parish since 1846 · St Joseph the Worker",
    tagline: "A church on the hill since 1846.",
    audience: "Parishioners, Mandarin & English congregations, neighbours",
    hero: "https://st-joseph.jesspete.shop/images/hero-church.jpg",
    heroFallback: "/images/joseph-church.jpg",
    heroAlt: "Whitewashed tower and green-tiled roof of St Joseph's, Bukit Timah",
    accent: "#335840",
  },
};

export const tokens: Token[] = [
  { name: "cream", hex: "#faf6ec", use: "Page ground" },
  { name: "parchment", hex: "#f2e9d6", use: "Section bands" },
  { name: "ink", hex: "#2a2115", use: "Body text" },
  { name: "maroon-500", hex: "#7c2a25", use: "Links, eyebrows" },
  { name: "maroon-700", hex: "#55191a", use: "Headings (light)" },
  { name: "maroon-900", hex: "#33100f", use: "Hero / footer" },
  { name: "maroon-950", hex: "#200a0a", use: "Header strip" },
  { name: "gold-300", hex: "#e2bf72", use: "Dark eyebrows" },
  { name: "gold-500", hex: "#c3963f", use: "Primary button" },
  { name: "pine-500", hex: "#335840", use: "Weave accent" },
  { name: "terracotta", hex: "#ab5f3c", use: "Community chip" },
  { name: "stone", hex: "#dccfae", use: "Borders" },
];

export const dimensions: Dimension[] = [
  {
    id: "identity",
    label: "Visual identity",
    weight: 0.15,
    rother: 9.0,
    joseph: 7.2,
    winner: "rother",
    thesis:
      "Rother authored the maroon–cream–gold–wheat language. St Joseph inherited it wholesale — including the crook-and-wheat emblem and shrine-* token names — so the Singapore parish still dresses like an Oklahoma shrine.",
    evidence:
      "Byte-identical @theme blocks in both src/index.css. St Joseph docs/porting.md records a direct port. Emblem remains crook + wheat.",
    confidence: "Verified",
  },
  {
    id: "color",
    label: "Color & contrast",
    weight: 0.12,
    rother: 8.2,
    joseph: 8.6,
    winner: "joseph",
    thesis:
      "The palette is the same; the craft is not. Rother shipped critical dark-band heading contrast (maroon-700 on maroon-950, ~1.39:1) and later patched it. St Joseph never had the defect, and adds a maroon custom scrollbar.",
    evidence:
      "rothershrine docs/design-remediation-plan-2026-08-29.md C-1–C-3; live CSS :focus-visible gold-500; St Joseph html scrollbar-color maroon/parchment.",
    confidence: "Verified",
  },
  {
    id: "type",
    label: "Typography",
    weight: 0.1,
    rother: 8.6,
    joseph: 8.4,
    winner: "rother",
    thesis:
      "Fraunces display + Source Sans 3 body, kern/liga on, text-wrap: balance. Rother's italic hero line is the more distinctive voice; St Joseph's roman 'church on the hill' is quieter and more parish-bulletin.",
    evidence:
      "Both index.html load Fraunces opsz 9..144 + Source Sans 3. Home copy: 'The shepherd who stayed.' vs 'A church on the hill since 1846.'",
    confidence: "Verified",
  },
  {
    id: "photo",
    label: "Photography",
    weight: 0.1,
    rother: 7.2,
    joseph: 8.6,
    winner: "joseph",
    thesis:
      "St Joseph ships eight local grounds photos plus a Wikimedia hero of the actual church. Rother ships four locals and leans on Pexels with SafeImage fallback — thinner sense of place.",
    evidence:
      "public/images: Rother 4 files; St Joseph 8 files + upload.wikimedia.org hero. SafeImage CDN→local fallback in both.",
    confidence: "Verified",
  },
  {
    id: "motion",
    label: "Motion",
    weight: 0.12,
    rother: 8.0,
    joseph: 8.8,
    winner: "joseph",
    thesis:
      "Both run the Sacred Motion package (rise-in, menu-in, drawer-in, card-lift, gold-rule, ken-burns, dot-pulse). St Joseph goes further: page-in route entrance, drawer-item stagger, and a gold scroll-progress hairline.",
    evidence:
      "src/index.css utilities compared line-for-line. St Joseph Layout.tsx keyed page-in; ScrollProgress.tsx + useScrollProgress.",
    confidence: "Verified",
  },
  {
    id: "ia",
    label: "Information architecture",
    weight: 0.1,
    rother: 8.4,
    joseph: 8.8,
    winner: "joseph",
    thesis:
      "Rother is a shrine visit: What to See, Pilgrimage, Volunteer. St Joseph is a living parish: Worship (mass/confession/find-us), Ministries jump-nav, Serve. The parish IA matches weekly user jobs more tightly.",
    evidence:
      "primaryNav in src/data/nav.ts. Rother 6 top-level / 2 dropdowns. St Joseph 6 top-level / 3 dropdowns + 7 alias paths.",
    confidence: "Verified",
  },
  {
    id: "a11y",
    label: "Accessibility",
    weight: 0.1,
    rother: 8.6,
    joseph: 8.7,
    winner: "joseph",
    thesis:
      "Both meet a high bar: skip link, 44px hamburger, gold focus-visible, global reduced-motion, aria-current, accordion inert. St Joseph adds aria-current on ministry pills and a larger jump-nav target after an earlier 40px hamburger fix.",
    evidence:
      "SkipLink, Header h-11, Accordion inert, prefers-reduced-motion in both index.css. St Joseph Ministries pills aria-current.",
    confidence: "Reasoned",
  },
  {
    id: "voice",
    label: "Content voice",
    weight: 0.08,
    rother: 9.0,
    joseph: 8.4,
    winner: "rother",
    thesis:
      "Rother's lede is unforgettable: a priest who fixed tractors better than he preached, and went back anyway. St Joseph is warm and local ('You are not a visitor here. You are expected.') but less singular.",
    evidence:
      "Home.tsx body copy, both repositories. Taglines from site.ts / Home hero.",
    confidence: "Verified",
  },
  {
    id: "seo",
    label: "Share & SEO",
    weight: 0.08,
    rother: 6.4,
    joseph: 9.0,
    winner: "joseph",
    thesis:
      "St Joseph ships Open Graph, Twitter card, og:image of the church, locale en_SG, and JSON-LD Church schema with Chinese alternateName. Rother has description + theme-color only.",
    evidence:
      "Live <head> of both deploys, fetched 2026. St Joseph schema.org Church + og:url https://st-joseph.jesspete.shop/.",
    confidence: "Verified",
  },
  {
    id: "mobile",
    label: "Mobile craft",
    weight: 0.05,
    rother: 8.2,
    joseph: 8.7,
    winner: "joseph",
    thesis:
      "Shared sticky maroon header and drawer-in. St Joseph staggers drawer items, closes the drawer on same-route taps, and restores double-hash anchors with an 80ms delay — fewer 'landed at top' misses.",
    evidence:
      "Header.tsx drawer-item-in; Layout.tsx resolveAnchor + setTimeout 80ms. Rother Layout is simpler scroll/hash restore.",
    confidence: "Reasoned",
  },
];

function weighted(site: "rother" | "joseph") {
  const total = dimensions.reduce((sum, d) => sum + d.weight * d[site], 0);
  return Math.round(total * 10) / 10;
}

export const overall = {
  rother: weighted("rother"),
  joseph: weighted("joseph"),
};

export const findings: Finding[] = [
  {
    id: "f-port",
    kind: "shared",
    site: "both",
    category: "System",
    title: "They are the same garment",
    body: "Identical shrine-* tokens, Fraunces + Source Sans 3, HashRouter single-file Vite SPAs, lucide-react, the same Header/Footer/PageHero/Timeline/Accordion/SafeImage kit. Comparing them is comparing a source to its port — not two independent designs.",
    evidence: "README design systems; empty diff on @theme blocks.",
    confidence: "Verified",
  },
  {
    id: "f-place",
    kind: "gap",
    site: "joseph",
    category: "Identity",
    title: "Oklahoma liturgy on a Singapore hill",
    body: "Maroon, wheat, adobe grain and a shepherd's crook read as Okarche farm and martyr's blood. They sit oddly on a whitewashed Palladian church among rain trees, with a Mandarin dawn Mass and a 1 May food fair. A parish-authored system would lean whitewash, tropical green, St Joseph's lilies or carpenter's square — and drop the shrine-* names.",
    evidence: "Emblem.tsx crook+wheat in both; token names shrine-* in st-joseph-bt src/index.css.",
    confidence: "Reasoned",
  },
  {
    id: "f-contrast",
    kind: "gap",
    site: "rother",
    category: "Color",
    title: "Hero headline once nearly vanished",
    body: "A global h1–h4 { text-shrine-maroon-700 } rule painted the home hero maroon-on-maroon (~1.39:1). PageHero already opted out with cream; Home and Give CTA bands did not. Fixed in the 2026-08-29 Sacred Motion pass with explicit text-shrine-cream (cream on maroon-950 = 17.5:1). The inheritance trap remains a regression risk.",
    evidence: "design-remediation-plan-2026-08-29.md C-1, C-2, C-3; dark-band-contrast tests.",
    confidence: "Verified",
  },
  {
    id: "f-motion-plus",
    kind: "strength",
    site: "joseph",
    category: "Motion",
    title: "The port out-polished the original",
    body: "St Joseph added page-in on pathname change (hash-only updates keep the node), drawer-item-in stagger, a decorative gold scroll-progress rail, and a themed scrollbar. Rother later ported the core Sacred Motion set upstream but still lacks those three extras.",
    evidence: "st-joseph index.css page-in / drawer-item-in; ScrollProgress.tsx; Layout keyed wrapper.",
    confidence: "Verified",
  },
  {
    id: "f-voice",
    kind: "strength",
    site: "rother",
    category: "Voice",
    title: "A line you cannot unhear",
    body: "“The shepherd who stayed.” Then: a priest who struggled through seminary Latin, who fixed tractors better than he preached, who went back anyway. That voice is the design. St Joseph's “You are not a visitor here. You are expected.” is hospitable, but it does not carry a martyr.",
    evidence: "Home.tsx ledes, both repos.",
    confidence: "Verified",
  },
  {
    id: "f-photo",
    kind: "strength",
    site: "joseph",
    category: "Imagery",
    title: "Eight rooms vs four postcards",
    body: "Chapel, sanctuary, rosary garden, stained glass, hall, cemetery, feast, hero — St Joseph lets you walk the grounds. Rother's four locals plus Pexels are serviceable, but the shrine's actual brick and wheat are under-photographed relative to the story they tell.",
    evidence: "public/images inventories in both READMEs.",
    confidence: "Verified",
  },
  {
    id: "f-ia",
    kind: "strength",
    site: "joseph",
    category: "IA",
    title: "Jobs-to-be-done, not shrine tourism",
    body: "A weekly Catholic needs Mass times, confession, MRT, PayNow. St Joseph puts those on Worship with hash restore and aliases (/mass-times, /visit, /donate). Rother correctly orients to pilgrimage (hours, tomb, Tepeyac) — right for a national shrine, thinner for a parish clone.",
    evidence: "nav.ts trees; App.tsx alias tables.",
    confidence: "Verified",
  },
  {
    id: "f-seo",
    kind: "gap",
    site: "rother",
    category: "SEO",
    title: "Nothing to unfurl",
    body: "Paste Rother's URL into a chat and you get a title and description. Paste St Joseph's and you get the whitewashed tower, schema.org Church, 圣若瑟堂, telephone and address. For a pilgrimage destination, that missing og:image is a real acquisition leak.",
    evidence: "Live HTML <head> comparison.",
    confidence: "Verified",
  },
  {
    id: "f-a11y",
    kind: "shared",
    site: "both",
    category: "A11y",
    title: "Sacred Motion is also an a11y contract",
    body: "Transform/opacity only, 180–700ms ease-out, global prefers-reduced-motion nuke plus explicit opt-outs for ken-burns and looping dot-pulse. Skip links never rewrite the HashRouter hash. Back-to-top is 44px and hash-preserving. This is above typical parish-site craft.",
    evidence: "index.css reduced-motion blocks; SkipLink tests; BackToTop tests.",
    confidence: "Reasoned",
  },
  {
    id: "f-chrome",
    kind: "gap",
    site: "rother",
    category: "Product",
    title: "No reading rail, no page entrance",
    body: "Long pages (History, What to See, Give) get BackToTop but no scroll-progress cue. Route changes pop. St Joseph's gold hairline under the header is a small thing that makes the shrine header feel unfinished by comparison.",
    evidence: "ScrollProgress exists only in st-joseph-bt.",
    confidence: "Verified",
  },
];

export const motionRows: MotionRow[] = [
  { name: "rise-in hero stagger", rother: true, joseph: true, note: "eyebrow → rule → h1 → lede → CTA" },
  { name: "hero ken-burns 20s", rother: true, joseph: true, note: "scale 1 → 1.05, reduced-motion off" },
  { name: "gold-rule draw", rother: true, joseph: true, note: "0.9s scaleX" },
  { name: "menu-in dropdown", rother: true, joseph: true, note: "180ms" },
  { name: "drawer-in panel", rother: true, joseph: true, note: "240ms" },
  { name: "drawer-item stagger", rother: false, joseph: true, note: "Joseph only" },
  { name: "page-in route", rother: false, joseph: true, note: "pathname-keyed, hash-safe" },
  { name: "card-lift hover", rother: true, joseph: true, note: "−4px + gold border" },
  { name: "link-underline", rother: true, joseph: true, note: "gold scaleX from left" },
  { name: "timeline dot-pulse", rother: true, joseph: true, note: "2.6s halo" },
  { name: "scroll-progress rail", rother: false, joseph: true, note: "gold hairline, aria-hidden" },
  { name: "themed scrollbar", rother: false, joseph: true, note: "maroon on parchment" },
  { name: "BackToTop 44px", rother: true, joseph: true, note: "appears after 480px" },
];

export const rotherNav: NavMap[] = [
  { label: "Home" },
  {
    label: "About",
    children: ["Blessed Stanley Rother", "History of the Shrine", "FAQ"],
  },
  {
    label: "What to See",
    children: ["Pilgrim Center", "Shrine Church & Chapel", "Tepeyac Hill"],
  },
  { label: "Pilgrimage" },
  { label: "News & Events" },
  { label: "Volunteer" },
];

export const josephNav: NavMap[] = [
  { label: "Home" },
  { label: "About", children: ["The Parish", "Our History", "FAQ"] },
  {
    label: "Worship",
    children: ["Mass Times", "Confession & Adoration", "Find Us"],
  },
  {
    label: "Ministries",
    children: ["Liturgical", "Faith Formation", "Pastoral Care"],
  },
  { label: "News & Events" },
  { label: "Serve" },
];

export const stack = [
  { layer: "UI", value: "React 19.2.8" },
  { layer: "Router", value: "HashRouter 7.18" },
  { layer: "Build", value: "Vite 7.3 + singlefile" },
  { layer: "Style", value: "Tailwind 4 @theme" },
  { layer: "Type", value: "TypeScript 5.9 strict" },
  { layer: "Motion", value: "CSS only — no Framer" },
];

export const methodNote =
  "Scores are reasoned from live HTML/CSS of both deploys, full GitHub source (tokens, Home, Header, Layout, nav, design-remediation docs), and line-level CSS diffs. Hydrated SPA screenshots were not captured in this pass; layout composition of inner pages is inferred from source. Confidence is tagged per claim.";

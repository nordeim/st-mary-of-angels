import { dimensions, overall } from "../data/audit";
import { Bar, Eyebrow, Section, SiteChip } from "./ui";

export function Scorecard() {
  return (
    <Section id="scorecard" className="mt-24 bg-paper py-20 text-ink sm:mt-32 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-8">
        <Eyebrow invert>04 · Weighted scorecard</Eyebrow>
        <div className="mt-4 grid gap-8 lg:grid-cols-12 lg:items-end">
          <h2 className="font-display text-3xl font-medium tracking-tight text-ink sm:text-5xl lg:col-span-7">
            Craft edges identity — barely.
          </h2>
          <p className="text-base leading-relaxed text-ink-muted lg:col-span-5">
            Ten dimensions, weighted. St Joseph wins more columns; Rother wins
            the ones that make a site feel inevitable. Overall{" "}
            <span className="text-ink">{overall.joseph.toFixed(1)}</span> vs{" "}
            <span className="text-ink">{overall.rother.toFixed(1)}</span>.
          </p>
        </div>

        <div className="mt-10 hidden grid-cols-[1.4fr_1fr_1fr_5.5rem] gap-x-4 border-b border-ink/15 pb-3 font-mono text-[10px] uppercase tracking-[0.2em] text-ink/40 md:grid">
          <span>Dimension</span>
          <span>Rother</span>
          <span>St Joseph</span>
          <span className="text-right">Lead</span>
        </div>

        <ol className="divide-y divide-ink/10">
          {dimensions.map((d, i) => (
            <li key={d.id} className="py-6 md:grid md:grid-cols-[1.4fr_1fr_1fr_5.5rem] md:gap-x-4 md:py-5">
              <div>
                <p className="font-display text-xl text-ink">{d.label}</p>
                <p className="mt-1 font-mono text-[10px] uppercase tracking-[0.16em] text-ink/40">
                  Weight {(d.weight * 100).toFixed(0)}% · {d.confidence}
                </p>
              </div>
              <div className="mt-4 md:mt-1">
                <div className="mb-2 flex items-baseline justify-between md:hidden">
                  <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink/40">
                    Rother
                  </span>
                  <span className="font-mono text-sm tabular-nums text-ink">
                    {d.rother.toFixed(1)}
                  </span>
                </div>
                <Bar value={d.rother} tone="rother" delay={i * 40} invert />
                <p className="mt-1 hidden font-mono text-sm tabular-nums text-ink/70 md:block">
                  {d.rother.toFixed(1)}
                </p>
              </div>
              <div className="mt-3 md:mt-1">
                <div className="mb-2 flex items-baseline justify-between md:hidden">
                  <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink/40">
                    St Joseph
                  </span>
                  <span className="font-mono text-sm tabular-nums text-ink">
                    {d.joseph.toFixed(1)}
                  </span>
                </div>
                <Bar value={d.joseph} tone="joseph" delay={i * 40 + 80} invert />
                <p className="mt-1 hidden font-mono text-sm tabular-nums text-ink/70 md:block">
                  {d.joseph.toFixed(1)}
                </p>
              </div>
              <div className="mt-3 flex md:mt-0 md:justify-end">
                <SiteChip site={d.winner} />
              </div>
              <p className="mt-4 text-sm leading-relaxed text-ink-muted md:col-span-4">
                {d.thesis}
              </p>
            </li>
          ))}
        </ol>
      </div>
    </Section>
  );
}

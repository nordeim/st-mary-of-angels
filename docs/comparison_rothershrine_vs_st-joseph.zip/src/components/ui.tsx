import { useState, type ReactNode } from "react";
import { cn } from "../utils/cn";
import type { SiteId, Winner } from "../data/audit";

export function SafeImg({
  src,
  fallback,
  alt,
  className,
}: {
  src: string;
  fallback: string;
  alt: string;
  className?: string;
}) {
  const [current, setCurrent] = useState(src);
  return (
    <img
      src={current}
      alt={alt}
      className={className}
      loading="lazy"
      onError={() => {
        if (current !== fallback) setCurrent(fallback);
      }}
    />
  );
}

export function Section({
  id,
  children,
  className,
}: {
  id: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section id={id} className={cn("scroll-mt-24", className)}>
      {children}
    </section>
  );
}

export function Eyebrow({
  children,
  invert = false,
}: {
  children: ReactNode;
  invert?: boolean;
}) {
  return (
    <p
      className={cn(
        "font-mono text-[11px] font-medium uppercase tracking-[0.28em]",
        invert ? "text-maroon-700" : "text-rule",
      )}
    >
      {children}
    </p>
  );
}

export function SiteChip({ site }: { site: SiteId | "both" | Winner }) {
  if (site === "tie" || site === "both") {
    return (
      <span className="inline-flex items-center rounded-sm border border-rule/40 px-2 py-0.5 font-mono text-[10px] uppercase tracking-[0.18em] text-rule">
        Both
      </span>
    );
  }
  const isRother = site === "rother";
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-sm px-2 py-0.5 font-mono text-[10px] uppercase tracking-[0.18em]",
        isRother
          ? "bg-rother text-cream"
          : "bg-joseph text-cream",
      )}
    >
      {isRother ? "Rother" : "St Joseph"}
    </span>
  );
}

export function ScoreNum({ value }: { value: number }) {
  return (
    <span className="font-mono text-[2rem] font-medium leading-none tracking-tight tabular-nums text-paper sm:text-[2.4rem]">
      {value.toFixed(1)}
    </span>
  );
}

export function Bar({
  value,
  tone,
  delay = 0,
  invert = false,
}: {
  value: number;
  tone: "rother" | "joseph";
  delay?: number;
  invert?: boolean;
}) {
  return (
    <div
      className={cn(
        "h-[5px] overflow-hidden rounded-full",
        invert ? "bg-ink/10" : "bg-paper/10",
      )}
    >
      <div
        className={cn(
          "fill-bar h-full origin-left rounded-full",
          tone === "rother" ? "bg-rother" : "bg-joseph",
        )}
        style={{
          width: `${value * 10}%`,
          animationDelay: `${delay}ms`,
        }}
      />
    </div>
  );
}

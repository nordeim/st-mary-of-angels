import { overall, sites } from "../data/audit";
import { Eyebrow, Section } from "./ui";

const recs = [
  {
    for: "Rother",
    items: [
      "Ship Open Graph + JSON-LD Place/Church. A national shrine with no unfurl image is leaving pilgrims on the table.",
      "Port page-in, drawer-item-in, and the gold scroll-progress rail from St Joseph — they already belong to this system.",
      "Photograph the actual grounds to replace Pexels. Four locals is not enough for Tepeyac, the tomb, and Oklahoma light.",
      "Keep the italic hero. Do not genericize “the shepherd who stayed.”",
    ],
  },
  {
    for: "St Joseph",
    items: [
      "Author a Bukit Timah token set. Whitewash, tropical pine, feast-day gold. Rename shrine-* — the name is a tell.",
      "Replace the crook-and-wheat emblem with St Joseph the Worker: lily, square, or the 1861 statue.",
      "Keep the motion extras, OG, schema, PayNow, MRT, and ministry jump-nav. That craft is the win.",
      "Let Mandarin (圣若瑟堂) live in the header, not only in JSON-LD.",
    ],
  },
];

export function Verdict() {
  return (
    <Section id="verdict" className="mt-24 sm:mt-32 pb-8">
      <div className="mx-auto max-w-7xl px-4 sm:px-8">
        <Eyebrow>06 · Verdict</Eyebrow>
        <h2 className="mt-4 max-w-4xl font-display text-3xl font-medium tracking-tight text-paper sm:text-5xl lg:text-6xl">
          St Joseph is the better{" "}
          <span className="italic text-gold-300">product</span>.
          Rother is the better{" "}
          <span className="italic text-gold-300">place</span>.
        </h2>
        <p className="mt-6 max-w-2xl text-lg leading-relaxed text-paper/70">
          Weighted {overall.joseph.toFixed(1)} to {overall.rother.toFixed(1)}.
          The parish port fixed contrast before the shrine did, added motion
          the original still lacks, and made itself shareable. It also still
          looks like Oklahoma. Until the tokens change, St Joseph will always
          be a beautifully maintained fork — not a church of its own hill.
        </p>

        <div className="mt-12 grid gap-6 lg:grid-cols-2">
          {recs.map((col) => (
            <div key={col.for} className="border border-rule/15 bg-panel p-7 sm:p-8">
              <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-rule">
                If you maintain {col.for}
              </p>
              <ol className="mt-6 space-y-5">
                {col.items.map((item, i) => (
                  <li key={item} className="flex gap-4">
                    <span className="font-mono text-xs text-rule/80">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span className="text-[15px] leading-relaxed text-paper/75">
                      {item}
                    </span>
                  </li>
                ))}
              </ol>
            </div>
          ))}
        </div>

        <div className="mt-12 gold-hairline" />

        <footer className="mt-10 flex flex-col gap-6 pb-16 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="font-display text-xl italic text-paper/80">
              Sister sites, 2026. Same hands, different altars.
            </p>
            <p className="mt-2 text-sm text-paper/40">
              Sources: live heads of both deploys, GitHub source, design-remediation
              plans. Not a legal or pastoral endorsement.
            </p>
          </div>
          <div className="flex flex-wrap gap-4 font-mono text-[11px] uppercase tracking-[0.16em]">
            <a
              className="text-rule hover:text-gold-300"
              href={sites.rother.repo}
              target="_blank"
              rel="noopener noreferrer"
            >
              Rother repo ↗
            </a>
            <a
              className="text-rule hover:text-gold-300"
              href={sites.joseph.repo}
              target="_blank"
              rel="noopener noreferrer"
            >
              Joseph repo ↗
            </a>
          </div>
        </footer>
      </div>
    </Section>
  );
}

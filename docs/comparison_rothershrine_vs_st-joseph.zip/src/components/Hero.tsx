import { overall, sites } from "../data/audit";
import { Eyebrow, SafeImg, ScoreNum, Section } from "./ui";

export function Hero() {
  return (
    <Section id="overview" className="relative overflow-hidden pt-24 sm:pt-28">
      <div className="grain absolute inset-0 opacity-80" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-8">
        <div className="grid gap-10 lg:grid-cols-12 lg:items-end lg:gap-12">
          <div className="lg:col-span-7">
            <Eyebrow>Audit 01 · Visual &amp; UI/UX</Eyebrow>
            <h1 className="rise mt-5 font-display text-[2.7rem] font-medium leading-[1.05] tracking-tight text-paper sm:text-6xl lg:text-7xl">
              Two churches.
              <span className="mt-1 block italic text-gold-300">
                One vestment.
              </span>
            </h1>
            <p className="rise rise-d2 mt-6 max-w-xl text-lg leading-relaxed text-paper/75 sm:text-xl">
              A comparative design audit of the Blessed Stanley Rother Shrine
              and St Joseph’s Church (Bukit Timah) — sister SPAs that share a
              token palette, a type pairing, and a motion language, then
              diverge in craft, photography, and sense of place.
            </p>
          </div>

          <div className="rise rise-d3 grid grid-cols-2 gap-6 lg:col-span-5">
            <ScoreCard
              kicker="Rother · identity"
              value={overall.rother}
              href={sites.rother.url}
            />
            <ScoreCard
              kicker="Joseph · craft"
              value={overall.joseph}
              href={sites.joseph.url}
              lead
            />
          </div>
        </div>

        <div className="mt-14 grid overflow-hidden rounded-sm lg:grid-cols-2">
          <Portrait site="rother" />
          <Portrait site="joseph" />
        </div>
      </div>
    </Section>
  );
}

function ScoreCard({
  kicker,
  value,
  href,
  lead = false,
}: {
  kicker: string;
  value: number;
  href: string;
  lead?: boolean;
}) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="group block border border-rule/20 bg-panel/80 p-5 transition-colors hover:border-rule/50"
    >
      <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-paper/50">
        {kicker}
      </p>
      <div className="mt-3 flex items-end justify-between gap-3">
        <ScoreNum value={value} />
        {lead ? (
          <span className="mb-1 font-mono text-[10px] uppercase tracking-[0.18em] text-rule">
            Edges
          </span>
        ) : null}
      </div>
      <p className="mt-3 font-mono text-[10px] uppercase tracking-[0.16em] text-paper/40 group-hover:text-rule">
        Open live ↗
      </p>
    </a>
  );
}

function Portrait({ site }: { site: "rother" | "joseph" }) {
  const s = sites[site];
  const isRother = site === "rother";
  return (
    <figure className="relative min-h-[18rem] sm:min-h-[26rem]">
      <SafeImg
        src={isRother ? s.heroFallback : s.hero}
        fallback={s.heroFallback}
        alt={s.heroAlt}
        className="absolute inset-0 h-full w-full object-cover"
      />
      <div
        className={
          isRother
            ? "absolute inset-0 bg-gradient-to-t from-rother-deep/90 via-rother-deep/25 to-transparent"
            : "absolute inset-0 bg-gradient-to-t from-joseph-deep/90 via-joseph-deep/25 to-transparent"
        }
      />
      <figcaption className="absolute inset-x-0 bottom-0 p-6 sm:p-8">
        <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-gold-300">
          {s.location}
        </p>
        <p className="mt-2 font-display text-2xl italic leading-snug text-cream sm:text-3xl">
          {s.tagline}
        </p>
        <p className="mt-2 max-w-sm text-sm text-cream/70">{s.name}</p>
      </figcaption>
    </figure>
  );
}

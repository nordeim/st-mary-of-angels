import { useEffect, useState } from "react";
import { cn } from "../utils/cn";

const links = [
  { href: "#overview", label: "Overview" },
  { href: "#live", label: "Live" },
  { href: "#dna", label: "DNA" },
  { href: "#scorecard", label: "Scorecard" },
  { href: "#findings", label: "Findings" },
  { href: "#verdict", label: "Verdict" },
];

export function Nav() {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("#overview");
  const [scrolled, setScrolled] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 12);
      const doc = document.documentElement;
      const max = doc.scrollHeight - doc.clientHeight;
      setProgress(max > 0 ? Math.min(1, window.scrollY / max) : 0);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const ids = links.map((l) => l.href.slice(1));
    const els = ids
      .map((id) => document.getElementById(id))
      .filter((el): el is HTMLElement => Boolean(el));
    const obs = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target.id) setActive(`#${visible.target.id}`);
      },
      { rootMargin: "-20% 0px -60% 0px", threshold: [0.1, 0.25, 0.5] },
    );
    els.forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, []);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 border-b transition-[background-color,border-color,backdrop-filter] duration-300",
        scrolled
          ? "border-rule/20 bg-void/90 backdrop-blur-md"
          : "border-transparent bg-transparent",
      )}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-8">
        <a href="#overview" className="flex items-center gap-3">
          <span className="grid h-8 w-8 place-items-center border border-rule/50 font-display text-sm text-rule">
            ∥
          </span>
          <span className="font-display text-lg tracking-tight text-paper">
            Sister Sites
          </span>
        </a>

        <nav className="hidden items-center gap-7 lg:flex" aria-label="Sections">
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className={cn(
                "relative font-mono text-[11px] uppercase tracking-[0.2em] transition-colors",
                active === link.href ? "text-rule" : "text-paper/55 hover:text-paper",
              )}
            >
              {link.label}
              {active === link.href ? (
                <span className="absolute -bottom-2 left-0 h-px w-full bg-rule" />
              ) : null}
            </a>
          ))}
        </nav>

        <button
          type="button"
          className="grid h-11 w-11 place-items-center border border-rule/30 text-paper lg:hidden"
          aria-expanded={open}
          aria-controls="mobile-nav"
          onClick={() => setOpen((v) => !v)}
        >
          <span className="sr-only">Menu</span>
          <span aria-hidden className="font-mono text-lg leading-none">
            {open ? "×" : "☰"}
          </span>
        </button>
      </div>
      <div
        className="h-px w-full bg-rule/15"
        aria-hidden
      >
        <div
          className="h-px w-full origin-left bg-rule"
          style={{ transform: `scaleX(${progress})` }}
        />
      </div>

      {open ? (
        <nav
          id="mobile-nav"
          className="border-t border-rule/20 bg-void/95 px-4 py-4 lg:hidden"
          aria-label="Mobile sections"
        >
          <ul className="grid gap-1">
            {links.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  className="block px-2 py-3 font-mono text-xs uppercase tracking-[0.22em] text-paper/80"
                  onClick={() => setOpen(false)}
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>
      ) : null}
    </header>
  );
}

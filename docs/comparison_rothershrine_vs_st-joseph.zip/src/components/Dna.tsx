import { useState } from "react";
import { stack, tokens } from "../data/audit";
import { Eyebrow, Section } from "./ui";

export function Dna() {
  const [copied, setCopied] = useState<string | null>(null);

  async function copyHex(hex: string) {
    try {
      await navigator.clipboard.writeText(hex);
      setCopied(hex);
      window.setTimeout(() => setCopied(null), 1400);
    } catch {
      setCopied(null);
    }
  }

  return (
    <Section id="dna" className="mt-24 sm:mt-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-8">
        <Eyebrow>03 · Shared DNA</Eyebrow>
        <h2 className="mt-4 max-w-3xl font-display text-3xl font-medium tracking-tight text-paper sm:text-5xl">
          The <span className="italic">shrine-*</span> system is byte-identical.
        </h2>
        <p className="mt-5 max-w-2xl text-base leading-relaxed text-paper/65 sm:text-lg">
          Cream ground, maroon ink, liturgical gold, pine weave, adobe grain.
          Fraunces for display, Source Sans 3 for body. This is not two design
          systems in conversation — it is one system worn by two houses.
        </p>

        <div className="mt-10 grid gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {tokens.map((t) => (
            <button
              key={t.name}
              type="button"
              onClick={() => copyHex(t.hex)}
              aria-label={`Copy ${t.name} ${t.hex}`}
              className="group border border-rule/15 bg-panel p-3 text-left transition-colors hover:border-rule/50"
            >
              <span
                className="block h-14 w-full rounded-sm"
                style={{ background: t.hex }}
                aria-hidden
              />
              <span className="mt-3 block font-mono text-[10px] uppercase tracking-[0.16em] text-paper/50">
                {t.name}
              </span>
              <span className="mt-1 block font-mono text-xs text-gold-300">
                {copied === t.hex ? "Copied" : t.hex}
              </span>
              <span className="mt-1 block text-xs text-paper/45">{t.use}</span>
            </button>
          ))}
        </div>

        <div className="mt-8 grid gap-px overflow-hidden border border-rule/15 bg-rule/15 sm:grid-cols-3 lg:grid-cols-6">
          {stack.map((row) => (
            <div key={row.layer} className="bg-void-soft p-4">
              <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-rule">
                {row.layer}
              </p>
              <p className="mt-2 text-sm text-paper">{row.value}</p>
            </div>
          ))}
        </div>

        <blockquote className="mt-12 max-w-3xl border-l-2 border-rule pl-6">
          <p className="font-display text-2xl italic leading-snug text-paper sm:text-3xl">
            “Keep the maroon/cream/gold liturgical palette and Fraunces display
            voice.”
          </p>
          <footer className="mt-4 font-mono text-[11px] uppercase tracking-[0.18em] text-paper/45">
            Both remediation plans · 2026-08
          </footer>
        </blockquote>
      </div>
    </Section>
  );
}

import { useState } from "react";
import { sites } from "../data/audit";
import { cn } from "../utils/cn";
import { Eyebrow, SafeImg, Section } from "./ui";

type Viewport = "desktop" | "tablet" | "mobile";

const widths: Record<Viewport, string> = {
  desktop: "100%",
  tablet: "768px",
  mobile: "390px",
};

export function LiveStage() {
  const [vp, setVp] = useState<Viewport>("desktop");
  const [showFrames, setShowFrames] = useState(false);

  return (
    <Section id="live" className="mt-24 sm:mt-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-8">
        <Eyebrow>02 · Live stage</Eyebrow>
        <div className="mt-4 flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <h2 className="max-w-2xl font-display text-3xl font-medium tracking-tight text-paper sm:text-4xl">
            Side by side, as a pilgrim and a parishioner would see them.
          </h2>
          <div className="flex flex-wrap items-center gap-2">
            {(["desktop", "tablet", "mobile"] as Viewport[]).map((v) => (
              <button
                key={v}
                type="button"
                onClick={() => setVp(v)}
                className={cn(
                  "h-11 px-4 font-mono text-[11px] uppercase tracking-[0.18em] transition-colors",
                  vp === v
                    ? "bg-rule text-void"
                    : "border border-rule/30 text-paper/70 hover:border-rule",
                )}
              >
                {v}
              </button>
            ))}
            <button
              type="button"
              onClick={() => setShowFrames((s) => !s)}
              className="h-11 border border-rule/30 px-4 font-mono text-[11px] uppercase tracking-[0.18em] text-paper/70 hover:border-rule"
              aria-pressed={showFrames}
            >
              {showFrames ? "Hide iframes" : "Peek live"}
            </button>
          </div>
        </div>

        <p className="mt-4 max-w-2xl text-sm leading-relaxed text-paper/55">
          Hosts may block embedding. If a frame is blank, use Open live — the
          comparison below is still valid from source and CSS.
        </p>

        <div className="mt-10 grid gap-6 lg:grid-cols-2">
          <Frame
            site="rother"
            vp={vp}
            showFrames={showFrames}
          />
          <Frame
            site="joseph"
            vp={vp}
            showFrames={showFrames}
          />
        </div>
      </div>
    </Section>
  );
}

function Frame({
  site,
  vp,
  showFrames,
}: {
  site: "rother" | "joseph";
  vp: Viewport;
  showFrames: boolean;
}) {
  const s = sites[site];
  return (
    <div>
      <div className="mb-3 flex items-baseline justify-between gap-3">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-rule">
            {s.short} · v{s.version}
          </p>
          <h3 className="font-display text-xl text-paper">{s.name}</h3>
        </div>
        <a
          href={s.url}
          target="_blank"
          rel="noopener noreferrer"
          className="font-mono text-[11px] uppercase tracking-[0.16em] text-paper/50 hover:text-rule"
        >
          Open live ↗
        </a>
      </div>
      <div className="device-frame overflow-hidden rounded-sm bg-void-soft">
        <div className="flex items-center gap-1.5 border-b border-rule/15 bg-panel px-3 py-2">
          <span className="h-2 w-2 rounded-full bg-rother/80" />
          <span className="h-2 w-2 rounded-full bg-rule/70" />
          <span className="h-2 w-2 rounded-full bg-joseph/80" />
          <span className="ml-2 truncate font-mono text-[10px] text-paper/40">
            {s.url.replace("https://", "")}
          </span>
        </div>
        <div className="flex justify-center bg-void">
          <div
            className="relative overflow-hidden bg-cream transition-[max-width] duration-500"
            style={{
              width: "100%",
              maxWidth: widths[vp],
              height: vp === "mobile" ? 560 : 520,
            }}
          >
            {showFrames ? (
              <iframe
                title={`${s.short} live preview`}
                src={s.url}
                className="h-full w-full bg-cream"
                loading="lazy"
              />
            ) : (
              <a
                href={s.url}
                target="_blank"
                rel="noopener noreferrer"
                className="block h-full w-full"
              >
                <SafeImg
                  src={s.hero}
                  fallback={s.heroFallback}
                  alt={s.heroAlt}
                  className="h-full w-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-void/70 via-transparent to-transparent" />
                <span className="absolute bottom-4 left-4 font-display text-lg italic text-cream">
                  {s.tagline}
                </span>
              </a>
            )}
          </div>
        </div>
      </div>
      <p className="mt-3 text-sm leading-relaxed text-paper/55">
        {s.founded}. {s.audience}.
      </p>
    </div>
  );
}

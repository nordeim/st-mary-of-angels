import { useState } from "react";
import {
  ALTAR_IMG,
  findings,
  josephNav,
  methodNote,
  motionRows,
  NAVE_IMG,
  rotherNav,
  WHEAT_IMG,
  type FindingKind,
} from "../data/audit";
import { cn } from "../utils/cn";
import { Eyebrow, Section, SiteChip } from "./ui";

const filters: { id: FindingKind | "all"; label: string }[] = [
  { id: "all", label: "All" },
  { id: "strength", label: "Strengths" },
  { id: "gap", label: "Gaps" },
  { id: "shared", label: "Shared" },
];

export function Findings() {
  const [filter, setFilter] = useState<FindingKind | "all">("all");
  const visible =
    filter === "all" ? findings : findings.filter((f) => f.kind === filter);

  return (
    <Section id="findings" className="mt-24 sm:mt-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-8">
        <Eyebrow>05 · Findings</Eyebrow>
        <h2 className="mt-4 max-w-3xl font-display text-3xl font-medium tracking-tight text-paper sm:text-5xl">
          Where the vestment fits — and where it strains.
        </h2>

        <div className="mt-8 flex flex-wrap gap-2" role="tablist" aria-label="Finding type">
          {filters.map((f) => (
            <button
              key={f.id}
              type="button"
              role="tab"
              aria-selected={filter === f.id}
              onClick={() => setFilter(f.id)}
              className={cn(
                "h-11 px-4 font-mono text-[11px] uppercase tracking-[0.18em]",
                filter === f.id
                  ? "bg-paper text-ink"
                  : "border border-rule/30 text-paper/70 hover:border-rule",
              )}
            >
              {f.label}
            </button>
          ))}
        </div>

        <ol className="mt-10 divide-y divide-rule/15">
          {visible.map((f, i) => (
            <li key={f.id} className="grid gap-4 py-10 sm:grid-cols-[4.5rem_1fr] sm:gap-10">
              <p className="font-mono text-sm text-rule/70">
                {String(i + 1).padStart(2, "0")}
              </p>
              <article>
                <div className="flex flex-wrap items-center gap-2">
                  <SiteChip site={f.site} />
                  <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-paper/40">
                    {f.category} · {f.confidence}
                  </span>
                </div>
                <h3
                  className={cn(
                    "mt-3 font-display text-paper",
                    i === 0 && filter === "all"
                      ? "text-3xl sm:text-4xl"
                      : "text-2xl",
                  )}
                >
                  {f.title}
                </h3>
                <p className="mt-4 max-w-3xl text-[16px] leading-relaxed text-paper/70">
                  {f.body}
                </p>
                <p className="mt-4 max-w-3xl font-mono text-[11px] leading-relaxed text-rule/75">
                  {f.evidence}
                </p>
              </article>
            </li>
          ))}
        </ol>

        <IaCompare />
        <MotionCompare />
        <PlaceStrip />

        <p className="mt-10 max-w-3xl text-sm leading-relaxed text-paper/45">
          {methodNote}
        </p>
      </div>
    </Section>
  );
}

function IaCompare() {
  return (
    <div className="mt-20">
      <Eyebrow>Information architecture</Eyebrow>
      <h3 className="mt-3 font-display text-2xl text-paper sm:text-3xl">
        Shrine tourism vs weekly parish jobs.
      </h3>
      <div className="mt-8 grid gap-6 md:grid-cols-2">
        <NavTree title="Rother" items={rotherNav} tone="rother" />
        <NavTree title="St Joseph" items={josephNav} tone="joseph" />
      </div>
    </div>
  );
}

function NavTree({
  title,
  items,
  tone,
}: {
  title: string;
  items: typeof rotherNav;
  tone: "rother" | "joseph";
}) {
  return (
    <div className="border border-rule/15 bg-void-soft p-6">
      <p
        className={cn(
          "font-mono text-[10px] uppercase tracking-[0.22em]",
          tone === "rother" ? "text-rother" : "text-joseph",
        )}
      >
        {title} · primaryNav
      </p>
      <ul className="mt-5 space-y-4">
        {items.map((item) => (
          <li key={item.label}>
            <p className="font-display text-lg text-paper">{item.label}</p>
            {item.children ? (
              <ul className="mt-2 space-y-1 border-l border-rule/25 pl-4">
                {item.children.map((c) => (
                  <li key={c} className="text-sm text-paper/60">
                    {c}
                  </li>
                ))}
              </ul>
            ) : null}
          </li>
        ))}
      </ul>
    </div>
  );
}

function MotionCompare() {
  return (
    <div className="mt-20">
      <Eyebrow>Motion inventory</Eyebrow>
      <h3 className="mt-3 font-display text-2xl text-paper sm:text-3xl">
        Sacred Motion, then three extras.
      </h3>
      <div className="mt-8 overflow-x-auto border border-rule/15">
        <table className="w-full min-w-[36rem] text-left text-sm">
          <thead className="bg-panel font-mono text-[10px] uppercase tracking-[0.18em] text-paper/50">
            <tr>
              <th className="px-4 py-3 font-medium">Utility</th>
              <th className="px-4 py-3 font-medium">Rother</th>
              <th className="px-4 py-3 font-medium">St Joseph</th>
              <th className="px-4 py-3 font-medium">Note</th>
            </tr>
          </thead>
          <tbody>
            {motionRows.map((row) => (
              <tr key={row.name} className="border-t border-rule/10">
                <td className="px-4 py-3 text-paper">{row.name}</td>
                <td className="px-4 py-3 font-mono text-xs">
                  <Mark on={row.rother} />
                </td>
                <td className="px-4 py-3 font-mono text-xs">
                  <Mark on={row.joseph} />
                </td>
                <td className="px-4 py-3 text-paper/50">{row.note}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Mark({ on }: { on: boolean }) {
  return (
    <span className={on ? "text-gold-300" : "text-paper/25"}>
      {on ? "Yes" : "—"}
    </span>
  );
}

function PlaceStrip() {
  return (
    <div className="mt-20 grid gap-3 md:grid-cols-3">
      <figure className="relative min-h-56 overflow-hidden">
        <img src={WHEAT_IMG} alt="Golden wheat at sunset" className="absolute inset-0 h-full w-full object-cover" />
        <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-void to-transparent p-4 font-display text-lg italic text-cream">
          Oklahoma wheat — the palette’s origin.
        </figcaption>
      </figure>
      <figure className="relative min-h-56 overflow-hidden">
        <img src={NAVE_IMG} alt="Ornate church interior with gold highlights" className="absolute inset-0 h-full w-full object-cover" />
        <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-void to-transparent p-4 font-display text-lg italic text-cream">
          Shared liturgical gold, different rooms.
        </figcaption>
      </figure>
      <figure className="relative min-h-56 overflow-hidden">
        <img src={ALTAR_IMG} alt="Baroque altar and stained glass" className="absolute inset-0 h-full w-full object-cover" />
        <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-void to-transparent p-4 font-display text-lg italic text-cream">
          Place wants its own ornament.
        </figcaption>
      </figure>
    </div>
  );
}

import { Dna } from "./components/Dna";
import { Findings } from "./components/Findings";
import { Hero } from "./components/Hero";
import { LiveStage } from "./components/LiveStage";
import { Nav } from "./components/Nav";
import { Scorecard } from "./components/Scorecard";
import { Verdict } from "./components/Verdict";

export default function App() {
  return (
    <div className="min-h-screen bg-void">
      <a className="skip-link" href="#overview">
        Skip to content
      </a>
      <Nav />
      <main>
        <Hero />
        <LiveStage />
        <Dna />
        <Scorecard />
        <Findings />
        <Verdict />
      </main>
    </div>
  );
}

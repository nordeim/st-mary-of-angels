export type SiteId = "joseph" | "mary";
export type Confidence = "Verified" | "Reasoned" | "Assumed" | "Unverifiable";
export type Winner = SiteId | "tie";

export interface ParishSite {
  id: SiteId;
  name: string;
  short: string;
  chinese: string;
  url: string;
  repo: string;
  version: string;
  established: number;
  address: string;
  feast: string;
  tagline: string;
  vision: string;
  hero: string;
  nave: string;
  heroAlt: string;
  naveAlt: string;
  tests: { unitFiles: number; unit: number; e2e: number };
  stack: string;
}

export interface Dimension {
  id: string;
  label: string;
  question: string;
  joseph: number;
  mary: number;
  winner: Winner;
  josephNote: string;
  maryNote: string;
}

export interface Finding {
  id: string;
  area: string;
  winner: Winner;
  severity: "decisive" | "material" | "nuance";
  title: string;
  evidence: string;
  impact: string;
  confidence: Confidence;
}

export const joseph: ParishSite = {
  id: "joseph",
  name: "St Joseph's Church (Bukit Timah)",
  short: "St Joseph BT",
  chinese: "圣若瑟堂",
  url: "https://st-joseph.jesspete.shop/",
  repo: "https://github.com/nordeim/st-joseph-bt",
  version: "1.1.0",
  established: 1846,
  address: "620 Upper Bukit Timah Road",
  feast: "1 May · St Joseph the Worker",
  tagline: "A church on the hill since 1846",
  vision: "A vibrant, evangelizing and missionary Church under the patronage of St Joseph.",
  hero: "/images/joseph-exterior.jpg",
  nave: "/images/joseph-nave.jpg",
  heroAlt: "Whitewashed colonial church with a green-tiled tower on a tropical hill",
  naveAlt: "Warm historic nave with timber pews and stained glass",
  tests: { unitFiles: 16, unit: 92, e2e: 35 },
  stack: "React 19 · Vite 7 · Tailwind 4 · HashRouter",
};

export const mary: ParishSite = {
  id: "mary",
  name: "Church of St Mary of the Angels",
  short: "St Mary of the Angels",
  chinese: "天神之后圣母堂",
  url: "https://st-mary-of-angels.jesspete.shop/",
  repo: "https://github.com/nordeim/st-mary-of-angels",
  version: "1.2.0",
  established: 1970,
  address: "5 Bukit Batok East Ave 2",
  feast: "2 August · Portiuncula",
  tagline: "According to Thy Word.",
  vision: "Towards a Prayerful & Missionary Parish — Pray · Form · Go.",
  hero: "/images/mary-exterior.jpg",
  nave: "/images/mary-nave.jpg",
  heroAlt: "Contemporary folded-roof church at dusk with gold light on angular planes",
  naveAlt: "Modern sanctuary with shafts of folded daylight",
  tests: { unitFiles: 25, unit: 141, e2e: 42 },
  stack: "React 19 · Vite 7 · Tailwind 4 · HashRouter",
};

export const method = {
  date: "2026-03-22",
  confidence: "Reasoned" as Confidence,
  caveat:
    "Both live deploys are single-file React SPAs. The HTML shell and inlined CSS were inspected directly; the hydrated DOM was not captured in this environment. Scores are therefore reasoned from live head/CSS, GitHub source (pages, components, tokens), and St Mary's Round-5 design plan — not from a pixel-level screenshot pass of the running SPA.",
  sources: [
    "Live HTML/CSS of both Cloudflare Pages deploys",
    "GitHub source: Header, Home, Worship, Button, SkipLink, index.css",
    "st-mary-of-angels docs/design-enhancement-round5-2026-08-30.md",
    "README design-system tables and routing contracts",
  ],
};

export const sharedDna = [
  {
    label: "Palette",
    detail: "Identical shrine-* tokens — cream #faf6ec, maroon-950 #200a0a, gold-500 #c3963f, pine, terracotta.",
  },
  {
    label: "Type",
    detail: "Fraunces display + Source Sans 3 body. Same optical sizes, same maroon headings.",
  },
  {
    label: "Motion",
    detail: "Sacred Motion set: rise-in stagger, hero Ken Burns, gold-rule draw, card-lift, link-underline, page-in.",
  },
  {
    label: "IA",
    detail: "10 pages, 17 HashRouter entries, 7 alias paths, #mass/#confession/#visit plus six ministry anchors.",
  },
  {
    label: "Chrome",
    detail: "Sticky maroon header, 4-column footer, weave dividers, grain overlay, skip-link, gold focus ring.",
  },
  {
    label: "Lineage",
    detail: "St Mary is a Rother → St Joseph → St Mary port. Visual kinship is architectural, not coincidental.",
  },
];

export const dimensions: Dimension[] = [
  {
    id: "identity",
    label: "Visual identity",
    question: "Does the site feel like this parish, or like a template wearing this parish's name?",
    joseph: 7.6,
    mary: 8.4,
    winner: "mary",
    josephNote:
      "The 1846 hill story is unmistakable in copy, but the chrome is the shared shrine skin. The Wikimedia hero of the whitewashed tower does the heavy lifting for place. No parish-specific motif beyond the crook-and-wheat emblem.",
    maryNote:
      "Same skin, but Round-5 adds a gold bloom on dark bands — a deliberate echo of WOHA's 'house of light'. Friar monogram discs and the Portiuncula tagline give the identity a Franciscan grain the palette alone cannot.",
  },
  {
    id: "type",
    label: "Typography & hierarchy",
    question: "Can a first-time visitor scan the page and know what matters?",
    joseph: 8.0,
    mary: 8.4,
    winner: "mary",
    josephNote:
      "Fraunces at 6–7xl on the hero, gold eyebrows at 0.35em tracking, balanced text-wrap. Event cards still flatten CATEGORY · DATE into one colored line — the hierarchy the design system promised never fully landed.",
    maryNote:
      "Same pairing, plus ghost numerals on Pray/Form/Go, EventMeta chips, and a gold-dot Sunday Mass list. About and News finally have a second typographic voice for metadata. Joseph still loads the 500 weight; Mary ships 400/600/700 only.",
  },
  {
    id: "material",
    label: "Color, texture, material",
    question: "Do surfaces feel liturgical and tactile, or merely themed?",
    joseph: 7.8,
    mary: 8.6,
    winner: "mary",
    josephNote:
      "Cream/parchment bands, adobe texture, SVG grain, weave dividers, shrine shadows. Dark CTA bands are flat adobe only. Hero relies on a maroon gradient veil over a CDN photograph.",
    maryNote:
      "Adds .bg-gold-bloom — a 640×320 radial of gold-300 at 10% opacity, anchored to dark bands. Combined with grain and adobe it reads as light in a nave, not a texture pack. Local images remove CDN flicker.",
  },
  {
    id: "motion",
    label: "Motion & micro-interaction",
    question: "Does motion teach, or merely decorate?",
    joseph: 7.2,
    mary: 8.9,
    winner: "mary",
    josephNote:
      "Rise-in stagger, 20s Ken Burns, card-lift, gold underline. Grounds and ministry photographs sit still inside lifting frames. Button icons do not nudge. Reduced-motion is globally gated.",
    maryNote:
      "Image-drift (.img-zoom 1.045 / 700ms) composes with card-lift. Button IconSlot translates on hover and is aria-hidden. Timeline halo, drawer-item stagger, and gold-rule are the same kit — used more completely.",
  },
  {
    id: "ia",
    label: "Information architecture",
    question: "Can someone find Mass, confession, and the door without hunting?",
    joseph: 8.0,
    mary: 8.2,
    winner: "mary",
    josephNote:
      "Primary nav with described dropdowns (Worship → Mass / Confession / Find Us). Footer 10-link map. Alias routes preserve old bookmarks. Hash-anchor restore is double-hash aware.",
    maryNote:
      "Identical map, with one UX upgrade: desktop dropdowns mark the current child. Sticky History story column keeps the 1957–2026 spine readable while the timeline scrolls — a layout IA Joseph still lacks.",
  },
  {
    id: "task",
    label: "Task success",
    question: "What time is Mass today? How do I give? How do I get there?",
    joseph: 7.0,
    mary: 9.0,
    winner: "mary",
    josephNote:
      "Mass cards exist, but all three share a Clock icon and none say 'today'. The visitor must self-locate in weekday / Saturday / Sunday. Give ends on the options grid. Maps iframe is present.",
    maryNote:
      "massDayKey() highlights exactly one card with a gold top rule and a Today chip. Sunday slots are a gold-dot list. Give closes on a dark band with Reception hours and a mailto. This is the single largest UX gap between the two.",
  },
  {
    id: "a11y",
    label: "Accessibility",
    question: "Would this pass a WCAG 2.2 AA pass on keyboard, name, and motion?",
    joseph: 7.8,
    mary: 8.7,
    winner: "mary",
    josephNote:
      "Skip-link avoids HashRouter collisions, gold :focus-visible, semantic landmarks, accordion is single-open. Decorative button icons are not aria-hidden at the primitive. Mobile drawer is not a focus-trapped dialog.",
    maryNote:
      "Round-4 drawer is a modal dialog: focus trap, restore, outside-tap close. IconSlot is aria-hidden. Reduced-motion block names every Sacred Motion class. Skip-link contrast (gold-300 on maroon-950) is safer than gold-500-on-cream for small type.",
  },
  {
    id: "mobile",
    label: "Mobile & navigation",
    question: "Does the parish-in-the-pocket hold together at 390px?",
    joseph: 7.5,
    mary: 8.6,
    winner: "mary",
    josephNote:
      "Hamburger drawer, same-route close regression covered in e2e, responsive grids to 1-col. Drawer entrance is translateY; it is not treated as a dialog, so background remains tabbable.",
    maryNote:
      "Drawer-item stagger plus true dialog semantics. Sticky History is lg-only (correct). Grounds cards remain tappable blocks. Round-4 closed an E2E race on the scroll rail.",
  },
  {
    id: "voice",
    label: "Voice & warmth",
    question: "Would a stranger feel expected, or processed?",
    joseph: 8.5,
    mary: 8.3,
    winner: "joseph",
    josephNote:
      "The 1846 attap-chapel-to-hill narrative is the strongest voice of the two. 'You are not a visitor here. You are expected.' Cemetery, tigers, rubber, milk-selling priest — specific, local, unforgettable. 16 PPC names make the household real.",
    maryNote:
      "Franciscan lyricism ('little portion of land', According to Thy Word) is excellent, but slightly more homiletic. Friar emails and language-community Masses (Mandarin, Tamil, Sinhala, Malayalam, Indonesian) are the warmth that is operational, not only poetic.",
  },
  {
    id: "craft",
    label: "Craft & QA",
    question: "Is the last 10% of polish actually finished?",
    joseph: 7.6,
    mary: 9.0,
    winner: "mary",
    josephNote:
      "16 unit files / 92 tests, 35 e2e, CSP allowing Wikimedia + Pexels. No host _headers. NotFound is a plain dark path. Give and History still show the Round-5 gaps that Mary's later pass closed.",
    maryNote:
      "25 files / 141 tests, 42 e2e, object-src none, Referrer-Policy, Cloudflare _headers (HSTS, XFO, Permissions-Policy), local imagery, NotFound emblem warmth, EventMeta extraction. This is a finished editorial object.",
  },
];

export const findings: Finding[] = [
  {
    id: "F1",
    area: "Worship",
    winner: "mary",
    severity: "decisive",
    title: "“What time is Mass today?” is answered only on St Mary",
    evidence:
      "Worship.tsx MassCard + massDayKey() — gold top rule, Today chip, data-today. St Joseph's three cards share a Clock icon and no day cue.",
    impact:
      "The most-asked parish question requires self-location on Joseph. Mary's highlight is the clearest UX win in the comparison.",
    confidence: "Reasoned",
  },
  {
    id: "F2",
    area: "Motion",
    winner: "mary",
    severity: "material",
    title: "Photographs drift on St Mary; they sit still on St Joseph",
    evidence:
      ".img-zoom in index.css; applied on Home grounds and Ministries. Joseph card-lift moves the frame only.",
    impact:
      "Hover affordance feels incomplete on Joseph. Mary's frame-lifts-photo-drifts pairing is the tactile finish the shared system implied.",
    confidence: "Reasoned",
  },
  {
    id: "F3",
    area: "Layout",
    winner: "mary",
    severity: "material",
    title: "History story column dead-ends on Joseph, sticks on Mary",
    evidence:
      "St Mary History.tsx uses lg:sticky lg:top-28. Round-5 audit R5-2 documented Joseph-lineage whitespace under the story column.",
    impact:
      "An eight-entry timeline with a short companion column reads as a layout bug on desktop. Sticky is the correct editorial fix.",
    confidence: "Reasoned",
  },
  {
    id: "F4",
    area: "Give",
    winner: "mary",
    severity: "material",
    title: "Give page closure",
    evidence:
      "Mary closes with a maroon-950 band, gold bloom, Reception hours, mailto, Serve cross-link. Joseph ends on the 8-option grid.",
    impact:
      "In-person giving facts stay buried. A donation page without a closing ritual feels abrupt after the rest of the shrine chrome.",
    confidence: "Reasoned",
  },
  {
    id: "F5",
    area: "A11y",
    winner: "mary",
    severity: "material",
    title: "Mobile drawer is a dialog only on St Mary",
    evidence:
      "Round-4 remediation: focus trap, focus restore, outside-tap. Joseph drawer closes on link activation but does not trap focus.",
    impact:
      "Keyboard and screen-reader users can tab into the page behind Joseph's open menu. WCAG 2.2 AA dialog pattern is not met there.",
    confidence: "Reasoned",
  },
  {
    id: "F6",
    area: "Identity",
    winner: "mary",
    severity: "nuance",
    title: "About page identity cues",
    evidence:
      "Mary: ghost numerals 01–03, friar monogram discs, PPC row hover. Joseph: small-caps numerals, text-only clergy, 16-row PPC table.",
    impact:
      "Joseph's larger household is more informative; Mary's cards are more scannable. Tradeoff: density vs. recognition.",
    confidence: "Reasoned",
  },
  {
    id: "F7",
    area: "Voice",
    winner: "joseph",
    severity: "nuance",
    title: "Joseph still writes the better origin myth",
    evidence:
      "Home welcome: French missionary, attap chapel, tigers, rubber, milk-selling priest. Mary's Portiuncula lyric is beautiful but more abstract.",
    impact:
      "If the brief is 'feel this hill', Joseph's copy outperforms a more polished chrome. Voice is the one dimension Joseph wins.",
    confidence: "Reasoned",
  },
  {
    id: "F8",
    area: "Performance",
    winner: "mary",
    severity: "nuance",
    title: "Imagery origin",
    evidence:
      "Joseph CSP allows upload.wikimedia.org + images.pexels.com. Mary ships 8 local images; legacy allowlist unused.",
    impact:
      "Joseph's hero can paint later or fail to a fallback. Mary is self-contained — better for a static single-file deploy.",
    confidence: "Verified",
  },
  {
    id: "F9",
    area: "Chrome",
    winner: "tie",
    severity: "nuance",
    title: "The design system is the same object",
    evidence:
      "Both @theme blocks list identical shrine-* hex values, shadows, and font-family tokens. Sacred Motion class names match.",
    impact:
      "This is not two visual languages. It is one language at two levels of finish. Scoring identity as a large gap would be dishonest.",
    confidence: "Verified",
  },
  {
    id: "F10",
    area: "Security headers",
    winner: "mary",
    severity: "nuance",
    title: "Host headers and CSP tightness",
    evidence:
      "Mary: object-src 'none', referrer meta, Cloudflare _headers (HSTS, X-Content-Type-Options, X-Frame-Options). Joseph: page CSP only.",
    impact:
      "Not a visual finding, but it is craft. The more finished site also ships the headers a static file cannot set alone.",
    confidence: "Verified",
  },
];

export const overall = {
  joseph: Number(
    (dimensions.reduce((sum, d) => sum + d.joseph, 0) / dimensions.length).toFixed(1),
  ),
  mary: Number((dimensions.reduce((sum, d) => sum + d.mary, 0) / dimensions.length).toFixed(1)),
};

export const recommendations = [
  {
    for: "joseph" as SiteId,
    title: "Port the Round-5 'Light of the Portiuncula' pass",
    body: "Today-Mass highlight, img-zoom, sticky History, Give closing band, EventMeta chips, IconSlot, gold-bloom. These are system-level, not parish-specific.",
  },
  {
    for: "joseph" as SiteId,
    title: "Promote the drawer to a dialog",
    body: "Focus trap, restore, and inert background. Joseph already has the same-route close test; add the dialog contract Mary's Round-4 closed.",
  },
  {
    for: "mary" as SiteId,
    title: "Let the building speak louder than the skin",
    body: "The WOHA church is Design of the Year. The shrine maroon skin still reads as a sibling of Bukit Timah. A cooler stone/daylight accent — used once — would separate Franciscan modernism from Josephite hill-station warmth without abandoning tokens.",
  },
  {
    for: "mary" as SiteId,
    title: "Restore the 500 weight, or stop using it",
    body: "Joseph loads Source Sans 3 400/500/600/700. Mary loads 400/600/700. If medium appears in the CSS, it will faux-bold. Align the font request with actual weights used.",
  },
];

import { method } from "../data/audit";

export function Method() {
  return (
    <section aria-labelledby="method-heading" className="border-y border-rule bg-paper-2/60">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-12 sm:px-8 lg:grid-cols-[0.8fr_1.2fr]">
        <div>
          <p className="text-[0.65rem] font-semibold uppercase tracking-[0.24em] text-copper">Method</p>
          <h2 id="method-heading" className="mt-2 font-display text-3xl text-forest-deep">
            How this was scored
          </h2>
        </div>
        <div>
          <p className="leading-relaxed text-ink-soft">{method.caveat}</p>
          <ul className="mt-6 grid gap-2 sm:grid-cols-2">
            {method.sources.map((source) => (
              <li
                key={source}
                className="border-l-2 border-copper/70 pl-3 text-sm leading-relaxed text-ink-soft"
              >
                {source}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}

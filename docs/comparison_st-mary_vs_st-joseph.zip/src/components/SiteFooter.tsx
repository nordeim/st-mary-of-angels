export function SiteFooter() {
  return (
    <footer className="border-t border-rule bg-forest-deep text-paper-3">
      <div className="mx-auto flex max-w-6xl flex-col gap-4 px-5 py-10 sm:flex-row sm:items-end sm:justify-between sm:px-8">
        <div>
          <p className="font-display text-2xl">Two Hills</p>
          <p className="mt-1 max-w-md text-sm text-paper-3/70">
            An independent visual and UX reading of two Archdiocese of Singapore parish sites that
            share a shrine design system.
          </p>
        </div>
        <p className="text-xs uppercase tracking-[0.16em] text-paper-3/55">
          Scores reasoned · CSS verified · SPA unhydrated
        </p>
      </div>
    </footer>
  );
}

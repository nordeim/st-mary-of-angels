import { sharedDna } from "../data/audit";

const tokens = [
  { name: "cream", hex: "#faf6ec" },
  { name: "parchment", hex: "#f2e9d6" },
  { name: "ink", hex: "#2a2115" },
  { name: "maroon-700", hex: "#55191a" },
  { name: "maroon-950", hex: "#200a0a" },
  { name: "gold-500", hex: "#c3963f" },
  { name: "gold-300", hex: "#e2bf72" },
  { name: "pine-500", hex: "#335840" },
];

export function SharedDna() {
  return (
    <section id="dna" className="mx-auto max-w-6xl px-5 py-20 sm:px-8 sm:py-28">
      <div className="max-w-2xl">
        <p className="text-[0.65rem] font-semibold uppercase tracking-[0.24em] text-copper">
          Shared DNA
        </p>
        <h2 className="mt-2 font-display text-4xl text-forest-deep text-balance">
          They are not two design systems. They are one system at two depths of finish.
        </h2>
        <p className="mt-5 leading-relaxed text-ink-soft">
          St Mary of the Angels is a documented port of St Joseph BT (itself a port of a Rother
          shrine). Comparing them as if they chose different aesthetics would miss the point. The
          interesting delta is craft: motion, task success, dialog semantics, and the last editorial
          10%.
        </p>
      </div>
      <div className="mt-10 flex flex-wrap gap-2" aria-label="Shared shrine palette">
        {tokens.map((token) => (
          <div
            key={token.name}
            className="flex items-center gap-2 rounded-sm border border-rule bg-paper-3 px-2 py-1.5"
          >
            <span
              className="h-6 w-6 rounded-sm border border-ink/10"
              style={{ background: token.hex }}
              aria-hidden="true"
            />
            <span className="text-[0.7rem] font-medium text-ink-soft">
              {token.name}
              <span className="ml-1 font-mono text-[0.62rem] uppercase">{token.hex}</span>
            </span>
          </div>
        ))}
      </div>
      <div className="mt-12 grid gap-px overflow-hidden rounded-sm border border-rule bg-rule sm:grid-cols-2 lg:grid-cols-3">
        {sharedDna.map((item) => (
          <article key={item.label} className="bg-paper-3 p-6">
            <h3 className="font-display text-2xl text-forest-deep">{item.label}</h3>
            <p className="mt-3 text-sm leading-relaxed text-ink-soft">{item.detail}</p>
          </article>
        ))}
      </div>
    </section>
  );
}

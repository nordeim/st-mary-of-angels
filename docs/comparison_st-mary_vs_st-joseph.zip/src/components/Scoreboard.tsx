import { useId, useState } from "react";
import { dimensions, type Dimension, type Winner } from "../data/audit";
import { cn } from "../utils/cn";

export function Scoreboard() {
  const [activeId, setActiveId] = useState(dimensions[0].id);
  const tabId = useId();
  const active = dimensions.find((d) => d.id === activeId) ?? dimensions[0];

  return (
    <section id="scoreboard" className="bg-forest-deep text-paper-3">
      <div className="mx-auto max-w-6xl px-5 py-20 sm:px-8 sm:py-28">
        <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
          <div>
            <p className="text-[0.65rem] font-semibold uppercase tracking-[0.24em] text-copper-soft">
              Scoreboard
            </p>
            <h2 className="mt-2 max-w-xl font-display text-4xl text-paper-3">
              Ten lenses. One later pass wins nine of them.
            </h2>
          </div>
          <p className="max-w-sm text-sm leading-relaxed text-paper-3/70">
            Joseph keeps voice. Mary keeps almost everything else. Tap a dimension.
          </p>
        </div>

        <div className="mt-12 grid gap-10 lg:grid-cols-[16rem_1fr]">
          <div
            role="tablist"
            aria-label="Audit dimensions"
            className="flex gap-2 overflow-x-auto pb-2 lg:flex-col lg:overflow-visible"
          >
            {dimensions.map((dimension) => {
              const selected = dimension.id === active.id;
              return (
                <button
                  key={dimension.id}
                  type="button"
                  role="tab"
                  id={`${tabId}-${dimension.id}`}
                  aria-selected={selected}
                  aria-controls={`${tabId}-panel`}
                  onClick={() => setActiveId(dimension.id)}
                  className={cn(
                    "shrink-0 rounded-sm border px-3 py-2.5 text-left text-sm transition-colors",
                    selected
                      ? "border-copper bg-copper text-paper-3"
                      : "border-paper-3/15 bg-transparent text-paper-3/80 hover:border-paper-3/40",
                  )}
                >
                  <span className="block font-semibold">{dimension.label}</span>
                  <span className="mt-0.5 block font-display text-xs tracking-wide">
                    {dimension.joseph.toFixed(1)} · {dimension.mary.toFixed(1)}
                  </span>
                </button>
              );
            })}
          </div>

          <DimensionPanel dimension={active} labelledBy={`${tabId}-${active.id}`} panelId={`${tabId}-panel`} />
        </div>
      </div>
    </section>
  );
}

function DimensionPanel({
  dimension,
  labelledBy,
  panelId,
}: {
  dimension: Dimension;
  labelledBy: string;
  panelId: string;
}) {
  return (
    <div
      role="tabpanel"
      id={panelId}
      aria-labelledby={labelledBy}
      className="rounded-sm border border-paper-3/15 bg-forest p-6 sm:p-10"
    >
      <p className="text-sm italic leading-relaxed text-paper-3/75">{dimension.question}</p>
      <div className="mt-8 space-y-5">
        <ScoreRow
          name="St Joseph BT"
          score={dimension.joseph}
          color="bg-joseph-soft"
          winner={dimension.winner === "joseph"}
        />
        <ScoreRow
          name="St Mary of the Angels"
          score={dimension.mary}
          color="bg-mary-soft"
          winner={dimension.winner === "mary"}
        />
      </div>
      <WinnerStamp winner={dimension.winner} />
      <div className="mt-8 grid gap-6 md:grid-cols-2">
        <Note kicker="St Joseph" body={dimension.josephNote} />
        <Note kicker="St Mary" body={dimension.maryNote} />
      </div>
    </div>
  );
}

function ScoreRow({
  name,
  score,
  color,
  winner,
}: {
  name: string;
  score: number;
  color: string;
  winner: boolean;
}) {
  return (
    <div>
      <div className="mb-2 flex items-baseline justify-between gap-3">
        <p className="text-sm font-semibold text-paper-3">
          {name}
          {winner ? (
            <span className="ml-2 text-[0.62rem] uppercase tracking-[0.16em] text-copper-soft">
              leads
            </span>
          ) : null}
        </p>
        <p className="font-display text-2xl text-paper-3">{score.toFixed(1)}</p>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-paper-3/10">
        <div
          className={cn("fill-bar h-full rounded-full", color)}
          style={{ width: `${score * 10}%` }}
        />
      </div>
    </div>
  );
}

function WinnerStamp({ winner }: { winner: Winner }) {
  const label =
    winner === "tie" ? "Even" : winner === "mary" ? "Mary leads" : "Joseph leads";
  return (
    <p className="mt-6 inline-flex border border-copper/50 px-3 py-1 text-[0.65rem] font-semibold uppercase tracking-[0.2em] text-copper-soft">
      {label}
    </p>
  );
}

function Note({ kicker, body }: { kicker: string; body: string }) {
  return (
    <article>
      <h3 className="text-[0.65rem] font-semibold uppercase tracking-[0.18em] text-copper-soft">
        {kicker}
      </h3>
      <p className="mt-2 text-sm leading-relaxed text-paper-3/85">{body}</p>
    </article>
  );
}

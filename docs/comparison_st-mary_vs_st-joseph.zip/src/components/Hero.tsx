import { ArrowUpRight } from "lucide-react";
import { joseph, mary, method, overall } from "../data/audit";

export function Hero() {
  return (
    <section id="top" className="relative overflow-hidden">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(900px_420px_at_10%_-10%,rgba(196,92,42,0.12),transparent_60%)]" />
      <div className="mx-auto grid max-w-6xl gap-10 px-5 pb-16 pt-12 sm:px-8 sm:pt-16 lg:grid-cols-[1.05fr_0.95fr] lg:pb-24">
        <div className="rise">
          <p className="text-[0.7rem] font-semibold uppercase tracking-[0.28em] text-copper">
            Visual aesthetic · UI/UX · {method.date}
          </p>
          <h1 className="mt-4 max-w-xl font-display text-[2.7rem] leading-[1.05] text-forest-deep text-balance sm:text-6xl">
            Two parishes.
            <br />
            One shrine skin.
            <span className="italic text-copper"> Different last miles.</span>
          </h1>
          <p className="mt-6 max-w-lg text-lg leading-relaxed text-ink-soft">
            St Joseph&apos;s Bukit Timah and St Mary of the Angels share a token palette, a type
            pairing, and a routing contract. The audit asks whether the later port merely renamed
            the hill — or finished the design.
          </p>
          <dl className="mt-10 grid grid-cols-2 gap-6 max-w-md">
            <div>
              <dt className="text-[0.65rem] uppercase tracking-[0.2em] text-joseph">St Joseph BT</dt>
              <dd className="mt-1 font-display text-5xl text-joseph">{overall.joseph.toFixed(1)}</dd>
              <dd className="mt-1 text-sm text-ink-soft">Voice of the older hill</dd>
            </div>
            <div>
              <dt className="text-[0.65rem] uppercase tracking-[0.2em] text-mary">St Mary</dt>
              <dd className="mt-1 font-display text-5xl text-mary">{overall.mary.toFixed(1)}</dd>
              <dd className="mt-1 text-sm text-ink-soft">Craft of the later pass</dd>
            </div>
          </dl>
          <p className="mt-8 max-w-lg text-sm leading-relaxed text-ink-soft">
            Scores out of 10 across ten dimensions. Confidence:{" "}
            <strong className="text-ink">{method.confidence}</strong> — live SPA did not hydrate in
            this environment; evidence is source, CSS, and deploy head.
          </p>
        </div>

        <div className="rise grid grid-cols-2 gap-3 sm:gap-4">
          <SiteCard site="joseph" />
          <SiteCard site="mary" />
        </div>
      </div>
    </section>
  );
}

function SiteCard({ site }: { site: "joseph" | "mary" }) {
  const data = site === "joseph" ? joseph : mary;
  const score = site === "joseph" ? overall.joseph : overall.mary;
  const accent = site === "joseph" ? "text-joseph" : "text-mary";

  return (
    <article className="group relative flex flex-col overflow-hidden rounded-sm border border-rule bg-paper-3 shadow-lift">
      <div className="relative aspect-[4/5] overflow-hidden">
        <img
          src={data.hero}
          alt={data.heroAlt}
          className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04]"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/10 to-transparent" />
        <p className={`absolute bottom-3 left-3 font-display text-3xl text-paper-3`}>{score.toFixed(1)}</p>
      </div>
      <div className="flex flex-1 flex-col p-4">
        <p className={`text-[0.62rem] font-semibold uppercase tracking-[0.18em] ${accent}`}>
          {data.established} · v{data.version}
        </p>
        <h2 className="mt-1 font-display text-xl leading-tight text-forest-deep">{data.short}</h2>
        <p className="mt-2 text-sm italic text-ink-soft">{data.tagline}</p>
        <a
          href={data.url}
          target="_blank"
          rel="noreferrer"
          className="mt-4 inline-flex items-center gap-1 text-sm font-semibold text-forest hover:text-copper"
        >
          Open live site
          <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
        </a>
      </div>
    </article>
  );
}

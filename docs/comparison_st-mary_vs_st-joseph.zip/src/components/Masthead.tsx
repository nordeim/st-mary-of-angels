import { overall } from "../data/audit";

const links = [
  { href: "#scoreboard", label: "Scores" },
  { href: "#dna", label: "Shared DNA" },
  { href: "#dives", label: "Deep dives" },
  { href: "#findings", label: "Findings" },
  { href: "#verdict", label: "Verdict" },
];

export function Masthead() {
  return (
    <header className="sticky top-0 z-40 border-b border-rule/70 bg-paper/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-5 py-3 sm:px-8">
        <a href="#top" className="group flex items-baseline gap-2">
          <span className="font-display text-xl tracking-tight text-forest-deep">Two Hills</span>
          <span className="hidden text-[0.65rem] uppercase tracking-[0.22em] text-ink-soft sm:inline">
            Parish design audit
          </span>
        </a>
        <nav
          aria-label="Audit sections"
          className="flex max-w-[55%] items-center gap-4 overflow-x-auto md:max-w-none md:gap-5"
        >
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="shrink-0 text-[0.68rem] font-semibold uppercase tracking-[0.16em] text-ink-soft transition-colors hover:text-copper"
            >
              {link.label}
            </a>
          ))}
        </nav>
        <p className="font-display text-sm text-ink-soft">
          <span className="text-joseph">{overall.joseph.toFixed(1)}</span>
          <span className="mx-1.5 text-rule">/</span>
          <span className="text-mary">{overall.mary.toFixed(1)}</span>
        </p>
      </div>
    </header>
  );
}

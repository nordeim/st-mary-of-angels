import { ArrowUpRight } from "lucide-react";
import { joseph, mary, overall, recommendations } from "../data/audit";

export function Verdict() {
  return (
    <section id="verdict" className="mx-auto max-w-6xl px-5 py-20 sm:px-8 sm:py-28">
      <p className="text-[0.65rem] font-semibold uppercase tracking-[0.24em] text-copper">Verdict</p>
      <h2 className="mt-2 max-w-3xl font-display text-4xl text-forest-deep text-balance sm:text-5xl">
        St Mary is the better-made website. St Joseph is still the better-told parish.
      </h2>
      <div className="mt-8 grid gap-8 lg:grid-cols-[1.2fr_0.8fr]">
        <div className="space-y-5 text-lg leading-relaxed text-ink-soft">
          <p>
            On visual aesthetic the two sites are kin — cream fields, maroon night, gold rules,
            Fraunces at display size. Scoring them as rival brands would be a category error. The
            honest score is {overall.mary.toFixed(1)} against {overall.joseph.toFixed(1)} because
            Mary closed a documented list of last-mile defects Joseph still carries: no Today on
            Mass, static photographs, a History column that dies at 40% height, a Give page with no
            closing band, a drawer that is not a dialog.
          </p>
          <p>
            Joseph wins the one dimension that cannot be ported by CSS: the 1846 voice. If a
            stranger must feel the hill, Joseph&apos;s copy still does more than Mary&apos;s
            (excellent) Franciscan lyric. The recommendation is not to restyle Joseph. It is to
            finish Joseph with Mary&apos;s Round-5 pass — and for Mary, to let the WOHA building
            pull the palette one degree toward stone and daylight so the sibling resemblance
            becomes kinship rather than duplication.
          </p>
        </div>
        <aside className="border border-rule bg-paper-3 p-6">
          <h3 className="font-display text-2xl text-forest-deep">Live artifacts</h3>
          <ul className="mt-4 space-y-3">
            <LiveLink site={joseph} />
            <LiveLink site={mary} />
          </ul>
          <p className="mt-6 text-sm leading-relaxed text-ink-soft">
            Unit/E2E as declared in each README: Joseph 92 + 35. Mary 141 + 42. Test counts are
            not visual quality, but they track the same finish gap.
          </p>
        </aside>
      </div>

      <h3 className="mt-16 font-display text-3xl text-forest-deep">What to do next</h3>
      <div className="mt-8 grid gap-4 md:grid-cols-2">
        {recommendations.map((item) => (
          <article key={item.title} className="border border-rule bg-paper-3 p-6">
            <p
              className={
                item.for === "joseph"
                  ? "text-[0.65rem] font-semibold uppercase tracking-[0.18em] text-joseph"
                  : "text-[0.65rem] font-semibold uppercase tracking-[0.18em] text-mary"
              }
            >
              For {item.for === "joseph" ? "St Joseph BT" : "St Mary of the Angels"}
            </p>
            <h4 className="mt-2 font-display text-2xl text-forest-deep">{item.title}</h4>
            <p className="mt-3 text-sm leading-relaxed text-ink-soft">{item.body}</p>
          </article>
        ))}
      </div>
    </section>
  );
}

function LiveLink({ site }: { site: typeof joseph }) {
  return (
    <li>
      <a
        href={site.url}
        target="_blank"
        rel="noreferrer"
        className="inline-flex items-center gap-1 font-semibold text-forest hover:text-copper"
      >
        {site.short}
        <ArrowUpRight className="h-3.5 w-3.5" aria-hidden="true" />
      </a>
      <span className="block text-sm text-ink-soft">
        <a href={site.repo} target="_blank" rel="noreferrer" className="hover:text-copper">
          GitHub source
        </a>
        {" · "}
        {site.address}
      </span>
    </li>
  );
}

import { findings, type Finding, type Winner } from "../data/audit";
import { cn } from "../utils/cn";

export function Findings() {
  return (
    <section id="findings" className="border-y border-rule bg-paper-2/50">
      <div className="mx-auto max-w-6xl px-5 py-20 sm:px-8 sm:py-28">
        <div className="max-w-2xl">
          <p className="text-[0.65rem] font-semibold uppercase tracking-[0.24em] text-copper">
            Findings
          </p>
          <h2 className="mt-2 font-display text-4xl text-forest-deep">
            Ten notes, ranked by how much they change a visit
          </h2>
        </div>
        <ol className="mt-12 divide-y divide-rule border-y border-rule">
          {findings.map((finding) => (
            <FindingRow key={finding.id} finding={finding} />
          ))}
        </ol>
      </div>
    </section>
  );
}

function FindingRow({ finding }: { finding: Finding }) {
  return (
    <li className="grid gap-4 py-8 lg:grid-cols-[6.5rem_1fr_11rem]">
      <div>
        <p className="font-display text-2xl text-forest-deep">{finding.id}</p>
        <p className="mt-1 text-[0.65rem] uppercase tracking-[0.16em] text-ink-soft">
          {finding.area}
        </p>
      </div>
      <div>
        <div className="flex flex-wrap items-center gap-2">
          <SeverityPill severity={finding.severity} />
          <WinnerPill winner={finding.winner} />
          <span className="text-[0.65rem] uppercase tracking-[0.14em] text-ink-soft">
            {finding.confidence}
          </span>
        </div>
        <h3 className="mt-3 font-display text-2xl text-forest-deep">{finding.title}</h3>
        <p className="mt-2 text-sm leading-relaxed text-ink-soft">
          <strong className="font-semibold text-ink">Evidence. </strong>
          {finding.evidence}
        </p>
        <p className="mt-2 text-sm leading-relaxed text-ink-soft">
          <strong className="font-semibold text-ink">Impact. </strong>
          {finding.impact}
        </p>
      </div>
      <p className="self-start text-sm italic text-ink-soft lg:text-right">{finding.area}</p>
    </li>
  );
}

function SeverityPill({ severity }: { severity: Finding["severity"] }) {
  const label =
    severity === "decisive" ? "Decisive" : severity === "material" ? "Material" : "Nuance";
  return (
    <span
      className={cn(
        "rounded-sm px-2 py-0.5 text-[0.62rem] font-semibold uppercase tracking-[0.14em]",
        severity === "decisive" && "bg-copper text-paper-3",
        severity === "material" && "bg-forest text-paper-3",
        severity === "nuance" && "bg-rule/70 text-ink",
      )}
    >
      {label}
    </span>
  );
}

function WinnerPill({ winner }: { winner: Winner }) {
  const label = winner === "tie" ? "Tie" : winner === "mary" ? "Mary" : "Joseph";
  const klass =
    winner === "tie"
      ? "text-ink-soft border-rule"
      : winner === "mary"
        ? "text-mary border-mary/40"
        : "text-joseph border-joseph/40";
  return (
    <span className={cn("rounded-sm border px-2 py-0.5 text-[0.62rem] font-semibold uppercase tracking-[0.14em]", klass)}>
      {label}
    </span>
  );
}

import { joseph, mary } from "../data/audit";

const dives = [
  {
    kicker: "Atmosphere",
    title: "The hero is the same machine",
    body: "Both open on a 92vh maroon-950 stage: Ken Burns over a parish photograph, dual gradients, grain, gold eyebrow, Fraunces display, four fact cells, two CTAs. Joseph's facts are Sunday Mass / Cashew MRT / 1 May / the hill. Mary's are 7.15–7 p.m. / Bukit Batok / Portiuncula / OFM. The template is identical; the facts are the parish.",
    image: joseph.nave,
    alt: joseph.naveAlt,
    caption: "Joseph — historic nave, timber and stained glass. The photograph does more brand work than the chrome.",
  },
  {
    kicker: "Worship",
    title: "One site tells you it is Tuesday",
    body: "Parish websites live or die on Mass times. Joseph presents weekday, Saturday, and Sunday as three equal parchment cards. Mary computes massDayKey(new Date()), paints a gold rule and a Today chip on exactly one card, and turns Sunday into a hoverable gold-dot list with Clock / MoonStar / Sun. That is not decoration. It is wayfinding.",
    image: mary.nave,
    alt: mary.naveAlt,
    caption: "Mary — folded light. The WOHA building wants a cooler material language than maroon-and-gold, and only almost gets it.",
  },
  {
    kicker: "Chrome",
    title: "Skip-links, drawers, buttons",
    body: "Both skip-links preventDefault so HashRouter does not route to /main-content. Joseph's is a gold pill sliding from above; Mary's is uppercase gold-on-maroon. Mary's Button wraps icons in an aria-hidden slot that nudges on hover. Mary's mobile menu is a focus-trapped dialog (Round-4). Joseph's menu is a drawer that closes on navigation but leaves the page tabbable behind it.",
    image: "/images/audit-desk.jpg",
    alt: "Design critic's desk with two parish homepage printouts side by side",
    caption: "Sibling artifacts. The honest comparison is finish, not invention.",
  },
];

export function DeepDives() {
  return (
    <section id="dives" className="mx-auto max-w-6xl px-5 py-20 sm:px-8 sm:py-28">
      <p className="text-[0.65rem] font-semibold uppercase tracking-[0.24em] text-copper">
        Deep dives
      </p>
      <h2 className="mt-2 max-w-2xl font-display text-4xl text-forest-deep">
        Where the eye actually goes
      </h2>
      <div className="mt-14 space-y-20">
        {dives.map((dive, index) => (
          <article
            key={dive.title}
            className="grid items-center gap-10 lg:grid-cols-2"
          >
            <div className={index % 2 === 1 ? "lg:order-2" : undefined}>
              <p className="text-[0.65rem] font-semibold uppercase tracking-[0.2em] text-copper">
                {dive.kicker}
              </p>
              <h3 className="mt-2 font-display text-3xl text-forest-deep">{dive.title}</h3>
              <p className="mt-4 leading-relaxed text-ink-soft">{dive.body}</p>
            </div>
            <figure className={index % 2 === 1 ? "lg:order-1" : undefined}>
              <img
                src={dive.image}
                alt={dive.alt}
                className="aspect-[16/11] w-full rounded-sm object-cover shadow-lift"
              />
              <figcaption className="mt-3 text-sm leading-relaxed text-ink-soft">
                {dive.caption}
              </figcaption>
            </figure>
          </article>
        ))}
      </div>
    </section>
  );
}

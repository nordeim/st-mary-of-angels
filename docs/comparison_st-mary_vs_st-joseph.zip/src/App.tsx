import { DeepDives } from "./components/DeepDives";
import { Findings } from "./components/Findings";
import { Hero } from "./components/Hero";
import { Masthead } from "./components/Masthead";
import { Method } from "./components/Method";
import { Scoreboard } from "./components/Scoreboard";
import { SharedDna } from "./components/SharedDna";
import { SiteFooter } from "./components/SiteFooter";
import { SkipLink } from "./components/SkipLink";
import { Verdict } from "./components/Verdict";

export default function App() {
  return (
    <>
      <SkipLink />
      <Masthead />
      <main id="main">
        <Hero />
        <Method />
        <SharedDna />
        <Scoreboard />
        <DeepDives />
        <Findings />
        <Verdict />
      </main>
      <SiteFooter />
    </>
  );
}
